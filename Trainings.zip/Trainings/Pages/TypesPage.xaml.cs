﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Trainings.Class;
using Trainings.Entity;

namespace Trainings.Pages
{
    /// <summary>
    /// Логика взаимодействия для TypesPage.xaml
    /// </summary>
    public partial class TypesPage : Page
    {
        public TypesPage()
        {
            InitializeComponent();
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.Navigate(new AddEditTypes(null));
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.GoBack();
        }

        private void BtnDel_Click(object sender, RoutedEventArgs e)
        {
            var elemforremoving = DGridTypes.SelectedItems.Cast<Types>().ToList();
            if (MessageBox.Show($"Вы точно хотите удалить следующие {elemforremoving.Count} записей?", "Внимание!", MessageBoxButton.YesNo) == MessageBoxResult.No) return;
            TrenyaEntities.GetContext().Types.RemoveRange(elemforremoving);
            TrenyaEntities.GetContext().SaveChanges();
            MessageBox.Show("Вы успешно удалили записи!");
            DGridTypes.ItemsSource = TrenyaEntities.GetContext().Types.ToList();
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.Navigate(new AddEditTypes((sender as Button).DataContext as Types));
        }

        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (Visibility == Visibility.Visible)
            {
                DGridTypes.ItemsSource = TrenyaEntities.GetContext().Types.ToList();
            }
        }
    }
}
