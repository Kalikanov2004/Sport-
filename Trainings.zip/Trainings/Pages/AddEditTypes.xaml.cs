﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Trainings.Class;
using Trainings.Entity;

namespace Trainings.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddEditTypes.xaml
    /// </summary>
    public partial class AddEditTypes : Page
    {
        private Types _currentType = new Types();
        public AddEditTypes(Types selected)
        {
            InitializeComponent();
            if (selected != null)
                _currentType = selected;
            DataContext = _currentType;
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(_currentType.name))
            {
                MessageBox.Show("Заполните все поля!");
            }
            else
            {
                if (_currentType.id == 0)
                {
                    TrenyaEntities.GetContext().Types.Add(_currentType);
                }
                try
                {
                    TrenyaEntities.GetContext().SaveChanges();
                    MessageBox.Show("Успешно!");
                    Manager.MainFrame.GoBack();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.GoBack();
        }
    }
}
