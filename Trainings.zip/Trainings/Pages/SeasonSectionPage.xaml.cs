﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Trainings.Class;
using Trainings.Entity;

namespace Trainings.Pages
{
    /// <summary>
    /// Логика взаимодействия для SeasonSectionPage.xaml
    /// </summary>
    public partial class SeasonSectionPage : Page
    {
        public SeasonSectionPage()
        {
            InitializeComponent();
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.GoBack();
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.Navigate(new AddEditSeasonSections(null));
        }

        private void BtnDel_Click(object sender, RoutedEventArgs e)
        {
            var elemforremoving = DGridSections.SelectedItems.Cast<SportSection>().ToList();
            if (MessageBox.Show($"Вы точно хотите удалить следующие {elemforremoving.Count} записей?", "Внимание!", MessageBoxButton.YesNo) == MessageBoxResult.No) return;
            TrenyaEntities.GetContext().SportSection.RemoveRange(elemforremoving);
            TrenyaEntities.GetContext().SaveChanges();
            MessageBox.Show("Вы успешно удалили записи!");
            DGridSections.ItemsSource = TrenyaEntities.GetContext().SportSection.ToList();
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.Navigate(new AddEditSeasonSections((sender as Button).DataContext as SportSection));
        }

        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (Visibility == Visibility.Visible)
            {
                DGridSections.ItemsSource = TrenyaEntities.GetContext().SportSection.ToList();
            }
        }
    }
}
