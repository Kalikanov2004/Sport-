﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Trainings.Class;
using Trainings.Entity;

namespace Trainings.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddEditTrainings.xaml
    /// </summary>
    public partial class AddEditTrainings : Page
    {
        private Entity.Trainings _currentTraining = new Entity.Trainings();
        private int selectedType;
        public AddEditTrainings(Entity.Trainings selected)
        {
            InitializeComponent();
            if (selected != null)
                _currentTraining = selected;
            DataContext = _currentTraining;
            CmbTypes.ItemsSource = TrenyaEntities.GetContext().Types.ToList();
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            _currentTraining.type_id = selectedType;
            if (string.IsNullOrWhiteSpace(_currentTraining.name) || string.IsNullOrWhiteSpace(_currentTraining.rules))
            {
                MessageBox.Show("Заполните все поля!");
            }
            else
            {
                if (_currentTraining.id == 0)
                {
                    TrenyaEntities.GetContext().Trainings.Add(_currentTraining);
                }
                try
                {
                    TrenyaEntities.GetContext().SaveChanges();
                    MessageBox.Show("Успешно!");
                    Manager.MainFrame.GoBack();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.GoBack();
        }

        private void CmbTypes_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (CmbTypes.SelectedItem is Types Name)
            {
                selectedType = Name.id;
            }
        }
    }
}
