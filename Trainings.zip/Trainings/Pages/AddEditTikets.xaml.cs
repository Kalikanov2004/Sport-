﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Trainings.Class;
using Trainings.Entity;

namespace Trainings.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddEditTikets.xaml
    /// </summary>
    public partial class AddEditTikets : Page
    {
        private SeasonTickets _currentTiket = new SeasonTickets();
        private int selectedUser;
        private int selectedSec;
        private int selectedTime;
        public AddEditTikets(SeasonTickets selected)
        {
            InitializeComponent();
            if (selected != null)
                _currentTiket = selected;
            DataContext = _currentTiket;
            CmbSection.ItemsSource = TrenyaEntities.GetContext().SportSection.ToList();
            CmbUser.ItemsSource = TrenyaEntities.GetContext().Users.ToList();
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.GoBack();
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            _currentTiket.sportSec_id = selectedSec;
            _currentTiket.user_id = selectedUser;
            _currentTiket.StartTime = DateTime.Now;
            if(CmbTime.SelectedIndex == 0)
            {
                _currentTiket.EndTime = DateTime.Now.AddMonths(3);
            } else
            {
                if(CmbTime.SelectedIndex == 1)
                {
                    _currentTiket.EndTime = DateTime.Now.AddMonths(6);
                } else
                {
                    _currentTiket.EndTime = DateTime.Now.AddYears(1);
                }
            }
                if (_currentTiket.id == 0)
                {
                    TrenyaEntities.GetContext().SeasonTickets.Add(_currentTiket);
                }
                try
                {
                    TrenyaEntities.GetContext().SaveChanges();
                    MessageBox.Show("Успешно!");
                    Manager.MainFrame.GoBack();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
        }

        private void CmbSection_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (CmbSection.SelectedItem is SportSection Name)
            {
                selectedSec = Name.id;
            }
        }

        private void CmbUser_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (CmbUser.SelectedItem is Users Name)
            {
                selectedUser = Name.id;
            }
        }
    }
}
