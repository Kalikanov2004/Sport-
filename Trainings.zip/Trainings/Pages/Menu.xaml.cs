﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Trainings.Class;

namespace Trainings.Pages
{
    /// <summary>
    /// Логика взаимодействия для Menu.xaml
    /// </summary>
    public partial class Menu : Page
    {
        public Menu()
        {
            InitializeComponent();
        }

        private void BtnTypes_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.Navigate(new TypesPage());
        }

        private void BtnTrenings_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.Navigate(new TrainingsPage());
        }

        private void BtnCoaches_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.Navigate(new CoachesPage());
        }

        private void BtnSeasonSections_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.Navigate(new SeasonSectionPage());
        }

        private void BtnTikets_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.Navigate(new TiketsPage());
        }

        private void BtnOut_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.GoBack();
        }
    }
}
