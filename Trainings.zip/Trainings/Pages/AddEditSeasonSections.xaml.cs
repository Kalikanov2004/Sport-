﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Trainings.Class;
using Trainings.Entity;

namespace Trainings.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddEditSeasonSections.xaml
    /// </summary>
    public partial class AddEditSeasonSections : Page
    {
        private SportSection _currentSec = new SportSection();
        private int selectedCoach;
        private int selectedTraining;
        public AddEditSeasonSections(SportSection selected)
        {
            InitializeComponent();
            if (selected != null)
                _currentSec = selected;
            DataContext = _currentSec;
            CmbCoach.ItemsSource = TrenyaEntities.GetContext().Coaches.ToList();
            CmbTraining.ItemsSource = TrenyaEntities.GetContext().Trainings.ToList();
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.GoBack();
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            _currentSec.Coach_id = selectedCoach;
            _currentSec.training_id = selectedTraining;
            if (string.IsNullOrWhiteSpace(_currentSec.name))
            {
                MessageBox.Show("Заполните все поля!");
            }
            else
            {
                if (_currentSec.id == 0)
                {
                    TrenyaEntities.GetContext().SportSection.Add(_currentSec);
                }
                try
                {
                    TrenyaEntities.GetContext().SaveChanges();
                    MessageBox.Show("Успешно!");
                    Manager.MainFrame.GoBack();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void CmbCoach_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (CmbCoach.SelectedItem is Coaches Name)
            {
                selectedCoach = Name.id;
            }
        }

        private void CmbTraining_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (CmbTraining.SelectedItem is Entity.Trainings Name)
            {
                selectedTraining = Name.id;
            }
        }
    }
}
