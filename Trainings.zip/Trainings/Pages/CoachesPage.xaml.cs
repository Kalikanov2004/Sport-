﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Trainings.Class;
using Trainings.Entity;

namespace Trainings.Pages
{
    /// <summary>
    /// Логика взаимодействия для CoachesPage.xaml
    /// </summary>
    public partial class CoachesPage : Page
    {
        public CoachesPage()
        {
            InitializeComponent();
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.GoBack();
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.Navigate(new AddEditCoahes(null));
        }

        private void BtnDel_Click(object sender, RoutedEventArgs e)
        {
            var elemforremoving = DGridCoaches.SelectedItems.Cast<Coaches>().ToList();
            if (MessageBox.Show($"Вы точно хотите удалить следующие {elemforremoving.Count} записей?", "Внимание!", MessageBoxButton.YesNo) == MessageBoxResult.No) return;
            TrenyaEntities.GetContext().Coaches.RemoveRange(elemforremoving);
            TrenyaEntities.GetContext().SaveChanges();
            MessageBox.Show("Вы успешно удалили записи!");
            DGridCoaches.ItemsSource = TrenyaEntities.GetContext().Coaches.ToList();
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.Navigate(new AddEditCoahes((sender as Button).DataContext as Coaches));
        }

        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (Visibility == Visibility.Visible)
            {
                DGridCoaches.ItemsSource = TrenyaEntities.GetContext().Coaches.ToList();
            }
        }
    }
}
