﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Trainings.Class;
using Trainings.Entity;

namespace Trainings.Pages
{
    /// <summary>
    /// Логика взаимодействия для TiketsPage.xaml
    /// </summary>
    public partial class TiketsPage : Page
    {
        public TiketsPage()
        {
            InitializeComponent();
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.Navigate(new AddEditTikets(null));
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.GoBack();
        }

        private void BtnDel_Click(object sender, RoutedEventArgs e)
        {
            var elemforremoving = DGridTikets.SelectedItems.Cast<SeasonTickets>().ToList();
            if (MessageBox.Show($"Вы точно хотите удалить следующие {elemforremoving.Count} записей?", "Внимание!", MessageBoxButton.YesNo) == MessageBoxResult.No) return;
            TrenyaEntities.GetContext().SeasonTickets.RemoveRange(elemforremoving);
            TrenyaEntities.GetContext().SaveChanges();
            MessageBox.Show("Вы успешно удалили записи!");
            DGridTikets.ItemsSource = TrenyaEntities.GetContext().SeasonTickets.ToList();
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.Navigate(new AddEditTikets((sender as Button).DataContext as SeasonTickets));
        }

        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (Visibility == Visibility.Visible)
            {
                DGridTikets.ItemsSource = TrenyaEntities.GetContext().SeasonTickets.ToList();
            }
        }
    }
}
