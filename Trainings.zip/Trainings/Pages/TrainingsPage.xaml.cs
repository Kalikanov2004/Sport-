﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Trainings.Class;
using Trainings.Entity;

namespace Trainings.Pages
{
    /// <summary>
    /// Логика взаимодействия для TrainingsPage.xaml
    /// </summary>
    public partial class TrainingsPage : Page
    {
        public TrainingsPage()
        {
            InitializeComponent();
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.GoBack();
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.Navigate(new AddEditTrainings(null));
        }

        private void BtnDel_Click(object sender, RoutedEventArgs e)
        {
            var elemforremoving = DGridTrainings.SelectedItems.Cast<Entity.Trainings>().ToList();
            if (MessageBox.Show($"Вы точно хотите удалить следующие {elemforremoving.Count} записей?", "Внимание!", MessageBoxButton.YesNo) == MessageBoxResult.No) return;
            TrenyaEntities.GetContext().Trainings.RemoveRange(elemforremoving);
            TrenyaEntities.GetContext().SaveChanges();
            MessageBox.Show("Вы успешно удалили записи!");
            DGridTrainings.ItemsSource = TrenyaEntities.GetContext().Trainings.ToList();
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.Navigate(new AddEditTrainings((sender as Button).DataContext as Entity.Trainings));
        }

        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (Visibility == Visibility.Visible)
            {
                DGridTrainings.ItemsSource = TrenyaEntities.GetContext().Trainings.ToList();
            }
        }
    }
}
