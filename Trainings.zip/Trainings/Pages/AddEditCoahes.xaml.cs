﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Trainings.Class;
using Trainings.Entity;

namespace Trainings.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddEditCoahes.xaml
    /// </summary>
    public partial class AddEditCoahes : Page
    {
        private Coaches _currentCoach = new Coaches();
        public AddEditCoahes(Coaches selected)
        {
            InitializeComponent();
            if (selected != null)
                _currentCoach = selected;
            DataContext = _currentCoach;
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(_currentCoach.fio) || string.IsNullOrWhiteSpace(_currentCoach.post) || string.IsNullOrWhiteSpace(_currentCoach.workExp))
            {
                MessageBox.Show("Заполните все поля!");
            }
            else
            {
                if (_currentCoach.id == 0)
                {
                    TrenyaEntities.GetContext().Coaches.Add(_currentCoach);
                }
                try
                {
                    TrenyaEntities.GetContext().SaveChanges();
                    MessageBox.Show("Успешно!");
                    Manager.MainFrame.GoBack();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.GoBack();
        }
    }
}
